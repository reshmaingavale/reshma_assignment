<?php
App::uses('AppController', 'Controller');
class EventAppController extends AppController {
    public function beforeFilter(){
        parent::beforeFilter();
    }

}
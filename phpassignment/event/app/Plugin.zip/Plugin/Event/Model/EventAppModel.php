<?php

class EventAppModel extends AppModel {
    var $name = 'Events';

}

